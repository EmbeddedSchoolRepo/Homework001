"""
Q1. Union이 여전히 import 안되는 이유가 무엇일까?

"""

def loadMathMod():
    print("import math")
    import math #함수 안에서 모듈import 가능 
    print(dir(math))

loadMathMod()

from ex35_mod import union

print(union([1,2,3],[3],[3,4]))