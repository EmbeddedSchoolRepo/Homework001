print("ex37 Test Module")
print("__name__", __name__)

if __name__ == '__main__':
    print("Direct Execution")
else:
    print("Import")