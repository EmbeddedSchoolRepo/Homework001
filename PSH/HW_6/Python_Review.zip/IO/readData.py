"""
f = open("./basics/IO/새파일.txt", 'r')
while True:
    line = f.readline()
    if not line: break
    print(line)
f.close()
"""
"""
f = open("./basics/IO/새파일.txt", 'r')
lines = f.readlines()
for line in lines:
    print(line)
f.close()
"""

f = open("./basics/IO/새파일.txt", 'r')
data = f.read()
print(data)
f.close()