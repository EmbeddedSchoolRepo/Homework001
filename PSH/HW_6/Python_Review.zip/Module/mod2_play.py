import mod2
a = mod2.Math()
print(a.solv(5))