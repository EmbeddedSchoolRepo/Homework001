"""
자식은 부모에 대한 인스턴스가 될 수 있음
"""

class Vehicle:
    pass

class Fish:
    pass

class Airplane(Vehicle): #부모class Vehicle로부터 상속받음
    pass

v, a = Vehicle(), Airplane()

print("v is instance of Vehicle:", isinstance(v, Vehicle))
print("a is instance of Vehicle:", isinstance(a, Vehicle))
print("v is instance of object:", isinstance(v, object)) #object는 파이썬 전체 관장하는 객체, 일종의 조상 클래스
print("v is instance of Fish:", isinstance(v, Fish))
print("int is instance of object:", isinstance(int, object))
"""
파이썬은 자동으로 데이터 타입을 정하지만 
커스텀으로 만든 자료형은 데이터 타입을 모르기 때문에
object로 받음(C의 void와 비슷한 개념)
"""