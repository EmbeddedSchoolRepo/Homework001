import ex35_mod

print(dir(ex35_mod))

setA = [1,3,7,10]
setB = [2,3,7,9]

print(ex35_mod.union(setA, setB))
print(ex35_mod.intersect(setA, setB, [1,2,3]))

### export PYTHONPATH=~~~~/ex35_mod to user everywhere
### export PYTHONPATH=경로/ex35_mod 하면 디렉토리 이동이나 추가 작업 없이
### ex35_mod를 불러와서 사용 가능함
import sys

print(sys.path)