class Person:
    def __init__(self, name, phoneNum):
        self.name = name
        self.phoneNum = phoneNum;
    
    def printInfo(self):
        print("Info(name:{0}, phone num: {1})".format(self.name, self.phoneNum))
    
    def printPersonData(self):
        print("Person(name:{0}, phonenum: {1})".format(self.name, self.phoneNum))
    
class Student(Person):
    def __init__(self, name, phoneNum, subject, studentId):
        self.name = name
        self.phoneNum = phoneNum
        self.subject = subject
        self.studentId = studentId

p = Person("Maron", "045-607-1853")
s = Student("Lunar", "406-708-3821", "Electronic Engineering", "7283492")

print(p.__dict__) # key : value 형태의 자동 dict타입 생성
print(s.__dict__)

print(issubclass(Student, Person))
print(issubclass(Person, Student))
print(issubclass(Person, Person))
print(issubclass(Person, object))
print(issubclass(Student, object))

class Test:
    pass

print(issubclass(Student, Test))
print(issubclass(Test, Person))
print(issubclass(Test, object))