"""
Person은 절대자 Person이 눈이 3개야 하면 p1, p2를 비롯한 
모든 객체의 눈은 3개가 됨
"""
class Person:
    Name = "Default Name"
    def Print(self): # 반드시 self를 인자로 받음
        print("My name is {0}".format(self.Name))

p1 = Person() # 동적 할당 후 시작주소 넘김
p1.Name = "My name is Python3"

p2 = Person()

print("p1's name: ", p1.Name)
print("p2's name: ", p2.Name)

Person.title = "Python3 Test" #새로운 class 맴버 생성됨, class의 모든 instance에 적용됨
print("p1's title:", p1.title)
print("p2's title:", p2.title)
print("Person's title:", Person.title)

p1.title = 20
print("p1's title:",p1.title)
print("p2's title:",p2.title)

