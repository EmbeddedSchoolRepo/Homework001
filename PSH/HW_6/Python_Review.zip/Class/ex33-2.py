class Person:
    def __init__(self, name, phoneNum):
        self.name = name
        self.phoneNum = phoneNum;
    
    def printInfo(self):
        print("Info(name:{0}, phone num: {1})".format(self.name, self.phoneNum))
    
    def printPersonData(self):
        print("Person(name:{0}, phonenum: {1})".format(self.name, self.phoneNum))
    
class Student(Person):
    def __init__(self, name, phoneNum, subject, studentId):
        self.name = name
        self.phoneNum = phoneNum
        self.subject = subject
        self.studentId = studentId

    def printStudentData(self):
        print("Student(subject: {0}, Student ID: {1})".format(self.subject, self.studentId))

    def printInfo(self):
        Person.printInfo(self) #부모(Person)의 printInfo 사용가능, Student가 상속받았기 때문에
        print("Info(subject: {0}, Student ID:{1})".format(self.subject, self.studentId))

p = Person("Maron", "045-607-1853")
s = Student("Lunar", "406-708-3821", "Electronic Engineering", "7283492")

print(p.__dict__) # key : value 형태의 자동 dict타입 생성
print(s.__dict__)

p.printInfo()
s.printInfo()