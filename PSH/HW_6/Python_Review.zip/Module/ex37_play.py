"""
_name__ == '__main__'
ex37_mod.py(내가 만든 모듈)을 직접 실행시키면 __name__ == '__main__'
이 되어 참참참

반대로 다른 파일에서 이 모듈을 import하여 사용할 때는 __name__ != '__main__'
이 되어 거짓거짓거짓
"""
import ex37_mod