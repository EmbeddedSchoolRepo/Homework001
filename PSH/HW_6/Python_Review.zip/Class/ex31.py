class Vehicles:
    def __init__(self, value):
        self.Value = value
        print("Vehicles Class Created! Value =", value)

    def __del__(self): #class 가 처음 생성할 때 생긴대로 초기화
        print("Vehicles Class Deleted!")

#def test():
t = Vehicles(333)
     #생성자는 사전에 초기화까지 가능함
     #함수 끝나면 객체가 소멸되기 때문에, 소멸자가 실행됨
     #전역으로 t = Vehicles(333)생성하면 프로그램 종료될때 까지 소멸자 실행x
#test()
