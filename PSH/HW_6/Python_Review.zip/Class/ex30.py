# pass를 해주어 그냥 빈 Class 만들어줌 #
class PyTestClass:
    """It's for Test Class"""
    pass

print(dir()) # 클래스 이름 공간이 생성된 것을 확인가능 
print(type(PyTestClass)) # type 'class'

class Person:
    Name = "Default Name"
    def Print(self):
        print("My name is {0}".format(self.Name))

p1 = Person() # c# class이름 
p1.Print()

p1.Name = "My name is Python3"
p1.Print() 
Person.Print(p1) #잘 사용하지는 않음, 객체를 self에 꼭 전달해야 함