
"""
Q.  주석 땡떙떙 3개는 라인 왼쪽에 무조건 붙여 써야 함!
    파일 test.txt라는 파일에 Life is too short 문자열을 저장한 후 다시 그 파일을 읽어서 출력하기
"""  

"""
with open solution #
close 자동생략해줌
"""
# with open("./basics/IO/test.txt", 'w') as f1:
#     f1.write("Life is too short")

# with open("./basics/IO/test.txt", 'r') as f2:
#     print(f2.readline())

"""
close()까지 쓰는 정석구조
습관적으로 close는 항상 쓰는 연습!
"""
# f1 = open("./basics/IO/test.txt", 'w')
# data = "Life is too short"
# f1.write(data)
# f1.close()

# f2 = open("./basics/IO/test.txt", 'r')
# data = f2.readline()
# print(data)
# f2.close()

"""
Q.  사용자 입력을 파일(test.txt)에 저장하는 프로그램을 작성하기(단, 기존에 작성한 내용을 유지하고 새로 입력한 내용을 추가해야함)
"""

# user_input = input("저장할 내용을 입력하세요:")
# f = open('./basics/IO/새파일.txt', 'a')
# f.write(user_input)
# f.write("\n")
# f.close()

"""
Q. Java라는 문자열을 Python으로 바꾸어서 저장해보기
    (replace()함수 이용하여 문자열 치환 가능)
"""

with open("./basics/IO/test.txt", 'r') as f1:
    data = f1.read()
    print(data)

data_replaced = data.replace("java", "python", 1) # 겸색문자, 치환문자, 치환횟수
print(data_replaced)

with open("./basics/IO/test.txt", 'w') as f2:
    f2.write(data_replaced) 