class CntManager:
    cnt = 0
    def __init__(self):
        CntManager.cnt += 1
    def staticPrintCnt():
        print("Instance cnt:", CntManager.cnt) 
    sPrintCnt = staticmethod(staticPrintCnt)

    def classPrintCnt(cls):
        print("Instance cnt:", cls.cnt)
    cPrintCnt = classmethod(classPrintCnt)

a, b, c = CntManager(), CntManager(), CntManager()

CntManager.sPrintCnt()
b.sPrintCnt()

CntManager.sPrintCnt()
b.cPrintCnt()