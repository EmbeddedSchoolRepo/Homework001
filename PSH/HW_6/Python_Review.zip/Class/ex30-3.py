"""
self를 이용하지 않을 경우 이름이 같은 전역변수에 접근함
"""
str1 = "Not Class Member"

class NonSelfTest:
    str1 = ""
    def Set(self,msg):
        self.str1 = msg
    
    def Print(self):
        print(str1) # self 이용안하면 위의 전역변수를 가리킴
        print(self.str1) #self.str1은 class 내의 str1을 말함
test = NonSelfTest()
test.Set("Test Messgae")
test.Print()