class ClassTest:
    data = "Default"

i1 = ClassTest()
i2 = ClassTest()

i1.__class__.data = "Change Data" # i1의 클래스.data 즉, ClassTest.data와 같은 의미, 절대자
print(i1.data)
print(i2.data)

i2.data = "Only Change it"
print(i1.data)
print(i2.data)

print(i2.__class__.data) #i2의 클래스.data 즉, ClassTest.data, 절대자
print(i1.data)
print(i2.data) # i2.data 는 11번째 줄에서 변경되었음 
